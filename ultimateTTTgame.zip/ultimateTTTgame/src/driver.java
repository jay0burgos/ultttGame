import java.lang.*;

public class driver {
    public static void main(String[] args) {
        //TTTGame game = new TTTGame();
        //game.playGame();
       UltimateTTTGame game = new UltimateTTTGame();
       game.playUltTTTGame();
       /*game.UltTTTBoards[0].setWinner("x");
       game.UltTTTBoards[0].setHasAWinner(true);
        game.UltTTTBoards[4].setWinner("x");
        game.UltTTTBoards[4].setHasAWinner(true);
        game.UltTTTBoards[8].setWinner("x");
        game.UltTTTBoards[8].setHasAWinner(true);
        System.out.println(game.UltTTTBoards[0].getHasAWinner());
        System.out.println(game.hasWon());*/
    }
}
